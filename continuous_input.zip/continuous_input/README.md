to compile, just type "make". An executable will form called input
Try the command "make clean" to remove that executable.
Check the makefile to see how I made it

#include <iostream>
#include <string>

using namespace std;

string solve(string s) {

}

int main(void) {
  string example = "cat";
  cout << "Testing cat: " << endl << 
    "Expected: tac" << endl << "Actual: " << 
    solve(example);
  return 0;
}

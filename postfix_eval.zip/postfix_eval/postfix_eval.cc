#include "stack.h"


int main(void) {

}
